Istructions for testing.

Open a terminal window pointing to your project folder.

If this is the first time you want to test, run: npm install
That will install all the dependencies.

For starting the game run: npm run dev

